import sys
import json
from awsglue.transforms import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from awsglue.utils import getResolvedOptions

# Get job parameters
args = getResolvedOptions(
    sys.argv,
    ['JOB_NAME', 'KAFKA_TOPIC_NAME', 'S3_OUTPUT_PATH']
)

kafka_topic = args['KAFKA_TOPIC_NAME']
s3_output_path = args['S3_OUTPUT_PATH']

# Initialize Glue context
sc = SparkContext()
glue_context = GlueContext(sc)
spark = glue_context.spark_session
job = Job(glue_context)
job.init(args['JOB_NAME'], args)

# Read from Kafka
kafka_stream = (
    spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", "<KAFKA_BOOTSTRAP_SERVERS>")
    .option("subscribe", kafka_topic)
    .option("startingOffsets", "earliest")
    .load()
)

# Deserialize Kafka messages
messages = kafka_stream.selectExpr("CAST(value AS STRING) as json_data")

# Define write logic to S3
query = (
    messages.writeStream
    .outputMode("append")
    .format("json")
    .option("path", s3_output_path)
    .option("checkpointLocation", f"{s3_output_path}/checkpoint/")
    .start()
)

query.awaitTermination()

# End Glue job
job.commit()
